'use client';

/**
 * Iconos SVG reales de redes sociales.
 *
 * Se usa SVG en línea en vez de emojis o letras porque los emojis varían
 * entre sistemas operativos (Windows, iOS, Android) y las letras no
 * transmiten la identidad de la marca. Los SVGs son consistentes en
 * cualquier navegador y mantienen la fidelidad de los colores oficiales
 * cuando el ícono lo requiere (ej: WhatsApp verde).
 *
 * Cada componente acepta `className` para controlar tamaño y color
 * (por defecto `currentColor`, así heredan el color del padre).
 *
 * Cuando `brandColor` es true, el ícono se renderiza con su color de
 * marca oficial (WhatsApp verde, Facebook azul, Instagram gradiente,
 * etc.) ignorando currentColor.
 */

type IconProps = { className?: string; brandColor?: boolean };

/**
 * Colores de marca oficiales de cada red social.
 * Se usan cuando `brandColor=true` en el componente Icon.
 */
export const SOCIAL_BRAND_COLORS: Record<string, string> = {
  whatsapp: '#25D366',   // Verde oficial de WhatsApp
  facebook: '#1877F2',   // Azul oficial de Facebook
  instagram: '#E4405F',  // Rosa/rojo característico de Instagram (simplificado del gradiente)
  telegram: '#26A5E4',   // Azul oficial de Telegram
  tiktok: '#000000',     // Negro de TikTok (los acentos cyan/rosa se simplifican)
  twitter: '#000000',    // X (ex-Twitter) ahora es negro
  youtube: '#FF0000',    // Rojo oficial de YouTube
};

export function WhatsAppIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.whatsapp : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.885-9.885 9.885M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.359.101 11.892c0 2.096.549 4.142 1.595 5.945L0 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.582 0 11.94-5.359 11.944-11.892a11.821 11.821 0 00-3.495-8.413z"/>
    </svg>
  );
}

export function FacebookIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.facebook : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
    </svg>
  );
}

export function InstagramIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  // Instagram oficial usa un gradiente, pero para mantener simplicidad
  // usamos el color rosa/rojo característico cuando brandColor=true.
  // El gradiente real es: #F58529 → #DD2A7B → #8134AF → #515BD4
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.instagram : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
    </svg>
  );
}

export function TelegramIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.telegram : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M23.91 3.79L20.3 20.84c-.25 1.21-.98 1.5-2 .94l-5.5-4.07-2.66 2.57c-.3.3-.55.56-1.1.56-.72 0-.6-.27-.84-.95L6.3 13.7l-5.45-1.7c-1.18-.35-1.19-1.16.26-1.75l21.26-8.2c.97-.43 1.9.24 1.53 1.73z"/>
    </svg>
  );
}

export function TikTokIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  // TikTok sobre fondo oscuro se ve mejor en blanco; sobre claro, en negro.
  // Usamos el negro característico de la marca.
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.tiktok : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.57-5.73-.06-1.05.03-2.11.31-3.12.55-2.05 2.05-3.84 4.04-4.66 1.43-.6 3.04-.69 4.55-.4.05 1.49-.01 2.97.01 4.46-.66-.22-1.4-.31-2.1-.13-1.36.31-2.5 1.45-2.74 2.85-.18.99.04 2.08.7 2.85.69.86 1.86 1.33 2.97 1.18 1.07-.12 2.05-.82 2.56-1.77.18-.36.27-.74.31-1.13.07-1.92.02-3.83.04-5.75.01-4.28-.01-8.56.02-12.84z"/>
    </svg>
  );
}

export function TwitterIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  // X (formerly Twitter) official icon
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.twitter : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
    </svg>
  );
}

export function YouTubeIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill={brandColor ? SOCIAL_BRAND_COLORS.youtube : 'currentColor'}
      className={className}
      aria-hidden
    >
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
    </svg>
  );
}

/**
 * Mapa de plataformas a componentes de íconos.
 * Las claves coinciden con los valores del select `icon` en el editor
 * de redes sociales del AdminPanel (whatsapp, facebook, instagram, etc.).
 *
 * Si una plataforma no está mapeada, se usa el icono genérico `GlobeIcon`.
 */
export const SOCIAL_ICON_MAP: Record<string, React.FC<IconProps>> = {
  whatsapp: WhatsAppIcon,
  facebook: FacebookIcon,
  instagram: InstagramIcon,
  telegram: TelegramIcon,
  tiktok: TikTokIcon,
  twitter: TwitterIcon,
  youtube: YouTubeIcon,
};

export function GlobeIcon({ className = 'h-5 w-5', brandColor = false }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke={brandColor ? '#6B7280' : 'currentColor'}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="2" y1="12" x2="22" y2="12" />
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    </svg>
  );
}

/**
 * Renderiza el ícono de una red social por nombre.
 * @param platform  Nombre de la plataforma (clave de SOCIAL_ICON_MAP).
 * @param className  Clases CSS para tamaño.
 * @param brandColor  Si true, usa el color oficial de la marca en vez de currentColor.
 */
export function SocialIcon({
  platform,
  className,
  brandColor = false,
}: {
  platform: string;
  className?: string;
  brandColor?: boolean;
}) {
  const Icon = SOCIAL_ICON_MAP[platform?.toLowerCase()] || GlobeIcon;
  return <Icon className={className} brandColor={brandColor} />;
}
